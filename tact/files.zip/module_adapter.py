"""
tact/module_adapter.py
======================
Thin binding between TACT and your existing model interface in src/module.py.

The decider only needs a callable `llm_call(messages: list[dict]) -> str`. Your
`llm_qwen3o` already has exactly that signature, so this is a one-line re-export
that also fixes up the import path whether you run from the repo root or from src/.

If you later want the decider to use a *different* model than the dialogue head
(e.g. a cheaper one for the transactional head), swap the binding here only.
"""

from __future__ import annotations


def _resolve_llm():
    try:
        from module import llm_qwen3o            # PYTHONPATH includes src/
        return llm_qwen3o
    except Exception:
        from src.module import llm_qwen3o         # running from repo root
        return llm_qwen3o


# the callable the decider expects: messages -> text
def llm_text(messages: list) -> str:
    return _resolve_llm()(messages)
